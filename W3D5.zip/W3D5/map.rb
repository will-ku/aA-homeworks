class Map

    attr_reader :mappy

    def initialize
        @mappy = Array.new {Array.new}
    end


end